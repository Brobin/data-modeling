#!/usr/bin/python

from numpy import *
import struct
import datetime

from models import Message, Record


def read_record(file):

	id = struct.unpack('i', file.read(4))[0]
	name = "".join(struct.unpack('s'*64, file.read(64)))
	location = "".join(struct.unpack('s'*32, file.read(32)))
	bullshit = struct.unpack('s'*32, file.read(32))
	num_messages = struct.unpack('i', file.read(4))[0]

	messages = []

	for x in range(0, num_messages):
		message = read_message(file)
		messages.append(message)

	record = Record(id, name, location, messages)
	return record

def read_message(file):
	text = "".join(struct.unpack('s'*1024, file.read(1024)))
	year = struct.unpack('i',file.read(4))[0]
	month = struct.unpack('i',file.read(4))[0]
	day = struct.unpack('i',file.read(4))[0]
	hour = struct.unpack('i',file.read(4))[0]
	minute = struct.unpack('i',file.read(4))[0]
	date = datetime.datetime(year, month, day, hour, minute)
	message = Message(date, text)
	return message


record  = open('record_000{0}.dat'.format('000'), 'rb')

processed_record = read_record(record)
print(processed_record)
